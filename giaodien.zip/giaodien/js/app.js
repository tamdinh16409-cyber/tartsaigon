// TART SAIGON - ADMIN PORTAL CORE LOGIC & MOCK DATABASE

// Initial Mock Data
const DEFAULT_CATEGORIES = [
    { id: 1, name: "Bánh Tart" },
    { id: 2, name: "Cà phê" },
    { id: 3, name: "Trà & Nước ép" },
    { id: 4, name: "Bánh ngọt khác" }
];

const DEFAULT_USERS = [
    { maUser: 1, tenDangNhap: "admin", hoTen: "Nguyễn Hoàng Minh", email: "admin@tartsaigon.vn", soDienThoai: "0901234567", vaiTro: "Quản trị viên", trangThai: true },
    { maUser: 2, tenDangNhap: "barista_vy", hoTen: "Trần Thảo Vy", email: "vy.tran@tartsaigon.vn", soDienThoai: "0908765432", vaiTro: "Barista", trangThai: true },
    { maUser: 3, tenDangNhap: "staff_duy", hoTen: "Phạm Khánh Duy", email: "duy.pham@tartsaigon.vn", soDienThoai: "0912345678", vaiTro: "Thu ngân", trangThai: true },
    { maUser: 4, tenDangNhap: "shipper_tai", hoTen: "Lê Tấn Tài", email: "tai.le@tartsaigon.vn", soDienThoai: "0987654321", vaiTro: "Giao hàng", trangThai: false }
];

const DEFAULT_PRODUCTS = [
    { maSanPham: 1, tenSanPham: "Bánh Tart Trứng", gia: 29000, hinhAnh: "Bánh Tart Trứng.jpg", maDanhMuc: 1, moTa: "Bánh tart trứng truyền thống với vỏ giòn tan và nhân kem sữa trứng béo ngậy." },
    { maSanPham: 2, tenSanPham: "Americano (đá)", gia: 35000, hinhAnh: "Americano (đá).jpg", maDanhMuc: 2, moTa: "Espresso đậm đà kết hợp với nước tinh khiết và đá lạnh mát mẻ." },
    { maSanPham: 3, maSanPham: 3, tenSanPham: "Cappuccino nóng", gia: 45000, hinhAnh: "Cappuccino nóng.jpg", maDanhMuc: 2, moTa: "Sự kết hợp hoàn hảo giữa espresso, sữa nóng và lớp bọt sữa dày mịn màng." },
    { maSanPham: 4, tenSanPham: "Bạc xỉu", gia: 39000, hinhAnh: "Bạc xỉu.jpg", maDanhMuc: 2, moTa: "Cà phê sữa kiểu Sài Gòn với lượng sữa nhiều hơn cà phê, thơm ngậy." },
    { maSanPham: 5, tenSanPham: "Croissant Bơ Tỏi", gia: 42000, hinhAnh: "Croissant Bơ Tỏi.jpg", maDanhMuc: 4, moTa: "Bánh sừng bò Pháp nướng thơm lừng với xốt bơ tỏi và ngò tây đặc trưng." },
    { maSanPham: 6, tenSanPham: "Trà Dâu Ổi hồng", gia: 49000, hinhAnh: "Trà Dâu Ổi hồng.jpg", maDanhMuc: 3, moTa: "Trà hoa quả nhiệt đới tươi mát thanh lọc cơ thể từ dâu tây và ổi hồng ngọt ngào." },
    { maSanPham: 7, tenSanPham: "Cà phê kem muối", gia: 45000, hinhAnh: "Cà phê kem muối.jpg", maDanhMuc: 2, moTa: "Cà phê phin truyền thống thơm nồng kết hợp với lớp màng kem muối mằn mặn béo ngậy." },
    { maSanPham: 8, tenSanPham: "Croissant Trứng Muối", gia: 45000, hinhAnh: "Croissant Trứng Muối.jpg", maDanhMuc: 4, moTa: "Bánh sừng bò giòn xốp với nhân trứng muối chảy thơm bùi hấp dẫn." }
];

const DEFAULT_CUSTOMERS = [
    { maKhachHang: 1, hoTen: "Phạm Minh Hoàng", soDienThoai: "0988888888", email: "hoangpm@gmail.com", diem: 180, hangThanhVien: "Vàng" },
    { maKhachHang: 2, hoTen: "Nguyễn Thảo Vy", soDienThoai: "0977777777", email: "vy.nguyen@gmail.com", diem: 85, hangThanhVien: "Bạc" },
    { maKhachHang: 3, hoTen: "Lê Anh Tuấn", soDienThoai: "0966666666", email: "tuan.le@gmail.com", diem: 350, hangThanhVien: "Kim cương" },
    { maKhachHang: 4, hoTen: "Đỗ Quỳnh Chi", soDienThoai: "0955555555", email: "chi.do@gmail.com", diem: 20, hangThanhVien: "Đồng" }
];

const DEFAULT_INVOICES = [
    {
        maHoaDon: 1001,
        ngayDat: "2026-07-03 10:30:15",
        loaiDon: "Tại bàn",
        tongTien: 103000,
        tongGiam: 10000,
        thanhTien: 93000,
        trangThai: "Đã thanh toán",
        khachHangId: 1,
        userId: 3,
        chiTiet: [
            { maSanPham: 1, tenSanPham: "Bánh Tart Trứng", soLuong: 2, donGia: 29000 },
            { maSanPham: 7, tenSanPham: "Cà phê kem muối", soLuong: 1, donGia: 45000 }
        ]
    },
    {
        maHoaDon: 1002,
        ngayDat: "2026-07-03 11:15:40",
        loaiDon: "Mang đi",
        tongTien: 74000,
        tongGiam: 0,
        thanhTien: 74000,
        trangThai: "Đang pha chế",
        khachHangId: 2,
        userId: 2,
        chiTiet: [
            { maSanPham: 4, tenSanPham: "Bạc xỉu", soLuong: 1, donGia: 39000 },
            { maSanPham: 2, tenSanPham: "Americano (đá)", soLuong: 1, donGia: 35000 }
        ]
    },
    {
        maHoaDon: 1003,
        ngayDat: "2026-07-02 16:45:00",
        loaiDon: "Giao hàng",
        tongTien: 185000,
        tongGiam: 20000,
        thanhTien: 165000,
        trangThai: "Sẵn sàng giao",
        khachHangId: 3,
        userId: 3,
        chiTiet: [
            { maSanPham: 1, tenSanPham: "Bánh Tart Trứng", soLuong: 4, donGia: 29000 },
            { maSanPham: 6, tenSanPham: "Trà Dâu Ổi hồng", soLuong: 1, donGia: 49000 },
            { maSanPham: 5, tenSanPham: "Croissant Bơ Tỏi", soLuong: 1, donGia: 42000 }
        ]
    }
];

// Helper to initialize local storage database
function initDatabase() {
    if (!localStorage.getItem("ts_categories")) {
        localStorage.setItem("ts_categories", JSON.stringify(DEFAULT_CATEGORIES));
    }
    if (!localStorage.getItem("ts_users")) {
        localStorage.setItem("ts_users", JSON.stringify(DEFAULT_USERS));
    }
    if (!localStorage.getItem("ts_products")) {
        localStorage.setItem("ts_products", JSON.stringify(DEFAULT_PRODUCTS));
    }
    if (!localStorage.getItem("ts_customers")) {
        localStorage.setItem("ts_customers", JSON.stringify(DEFAULT_CUSTOMERS));
    }
    if (!localStorage.getItem("ts_invoices")) {
        localStorage.setItem("ts_invoices", JSON.stringify(DEFAULT_INVOICES));
    }
}

// Database Getters & Setters
const DB = {
    getUsers: () => JSON.parse(localStorage.getItem("ts_users")),
    saveUsers: (data) => localStorage.setItem("ts_users", JSON.stringify(data)),
    
    getProducts: () => JSON.parse(localStorage.getItem("ts_products")),
    saveProducts: (data) => localStorage.setItem("ts_products", JSON.stringify(data)),
    
    getCategories: () => JSON.parse(localStorage.getItem("ts_categories")),
    saveCategories: (data) => localStorage.setItem("ts_categories", JSON.stringify(data)),

    getCustomers: () => JSON.parse(localStorage.getItem("ts_customers")),
    saveCustomers: (data) => localStorage.setItem("ts_customers", JSON.stringify(data)),
    
    getInvoices: () => JSON.parse(localStorage.getItem("ts_invoices")),
    saveInvoices: (data) => localStorage.setItem("ts_invoices", JSON.stringify(data)),
};

// Auto-run initialization
initDatabase();

// --- Sidebar Helper ---
function renderSidebar(activeMenu = "dashboard", isSubdir = false) {
    const prefix = isSubdir ? "../" : "./";
    const sidebarHtml = `
        <div class="sidebar-header">
            <img src="${prefix}../usecase/img2/logo.jpg" alt="Tart Saigon" class="sidebar-logo">
            <div class="sidebar-brand">
                <h2>Tart Saigon</h2>
                <span>Hệ Thống Admin</span>
            </div>
        </div>
        <div class="sidebar-nav">
            <span class="nav-section-title">Tổng quan</span>
            <a href="${prefix}index.html" class="nav-item ${activeMenu === 'dashboard' ? 'active' : ''}">
                <i class="fa-solid fa-chart-pie"></i>
                <span>Bảng điều khiển</span>
            </a>
            
            <span class="nav-section-title">Vận hành cửa hàng</span>
            <a href="${prefix}hoadon/pos.html" class="nav-item ${activeMenu === 'pos' ? 'active' : ''}">
                <i class="fa-solid fa-cash-register"></i>
                <span>Bán hàng POS</span>
            </a>
            <a href="${prefix}hoadon/list.html" class="nav-item ${activeMenu === 'hoadon' ? 'active' : ''}">
                <i class="fa-solid fa-file-invoice-dollar"></i>
                <span>Quản lý Hóa đơn</span>
            </a>
            <a href="${prefix}sanpham/list.html" class="nav-item ${activeMenu === 'sanpham' ? 'active' : ''}">
                <i class="fa-solid fa-cookie-bite"></i>
                <span>Quản lý Sản phẩm</span>
            </a>
            <a href="${prefix}khachhang/list.html" class="nav-item ${activeMenu === 'khachhang' ? 'active' : ''}">
                <i class="fa-solid fa-users"></i>
                <span>Quản lý Khách hàng</span>
            </a>
            <a href="${prefix}users/list.html" class="nav-item ${activeMenu === 'users' ? 'active' : ''}">
                <i class="fa-solid fa-user-shield"></i>
                <span>Nhân viên & Admin</span>
            </a>
        </div>
        <div class="sidebar-footer">
            <div class="sidebar-avatar">QT</div>
            <div class="sidebar-user-info">
                <div class="name">Nguyễn Hoàng Minh</div>
                <div class="role">Quản trị viên</div>
            </div>
            <button class="sidebar-logout" title="Đăng xuất" onclick="alert('Đăng xuất thành công!')">
                <i class="fa-solid fa-right-from-bracket"></i>
            </button>
        </div>
    `;

    const sidebarContainer = document.getElementById("sidebar");
    if (sidebarContainer) {
        sidebarContainer.innerHTML = sidebarHtml;
    }

    // Add Mobile sidebar support
    const overlay = document.createElement("div");
    overlay.className = "sidebar-overlay";
    overlay.id = "sidebar-overlay";
    document.body.appendChild(overlay);

    const toggleBtn = document.createElement("button");
    toggleBtn.className = "sidebar-toggle";
    toggleBtn.id = "sidebar-toggle";
    toggleBtn.innerHTML = '<i class="fa-solid fa-bars"></i>';
    document.body.appendChild(toggleBtn);

    toggleBtn.addEventListener("click", () => {
        sidebarContainer.classList.toggle("open");
        overlay.classList.toggle("show");
    });

    overlay.addEventListener("click", () => {
        sidebarContainer.classList.remove("open");
        overlay.classList.remove("show");
    });
}

// --- Notifications / Toasts ---
function showToast(message, type = "success") {
    let container = document.getElementById("toast-container");
    if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        container.id = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    
    let icon = "fa-circle-check";
    if (type === "danger") icon = "fa-triangle-exclamation";
    if (type === "warning") icon = "fa-circle-exclamation";

    toast.innerHTML = `
        <i class="toast-icon fa-solid ${icon}"></i>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()"><i class="fa-solid fa-xmark"></i></button>
    `;

    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = "toastSlideOut 0.4s ease forwards";
        setTimeout(() => toast.remove(), 400);
    }, 4000);
}

// --- Delete Confirmation Modal ---
let pendingDeleteAction = null;

function showDeleteConfirmModal(title, message, onConfirm) {
    let modalOverlay = document.getElementById("delete-modal-overlay");
    if (!modalOverlay) {
        modalOverlay = document.createElement("div");
        modalOverlay.className = "modal-overlay";
        modalOverlay.id = "delete-modal-overlay";
        modalOverlay.innerHTML = `
            <div class="modal">
                <div class="modal-icon danger">
                    <i class="fa-solid fa-trash-can"></i>
                </div>
                <h3 id="delete-modal-title">Xác nhận xóa</h3>
                <p id="delete-modal-message">Bạn có chắc muốn thực hiện thao tác này? Thao tác này không thể hoàn tác.</p>
                <div class="modal-actions">
                    <button class="btn btn-secondary" id="delete-modal-cancel">Hủy</button>
                    <button class="btn btn-danger" id="delete-modal-confirm">Xóa bỏ</button>
                </div>
            </div>
        `;
        document.body.appendChild(modalOverlay);

        document.getElementById("delete-modal-cancel").addEventListener("click", hideDeleteConfirmModal);
        document.getElementById("delete-modal-confirm").addEventListener("click", () => {
            if (pendingDeleteAction) {
                pendingDeleteAction();
                pendingDeleteAction = null;
            }
            hideDeleteConfirmModal();
        });
    }

    document.getElementById("delete-modal-title").innerText = title;
    document.getElementById("delete-modal-message").innerText = message;
    pendingDeleteAction = onConfirm;
    
    modalOverlay.style.display = "flex";
    setTimeout(() => modalOverlay.classList.add("show"), 10);
}

function hideDeleteConfirmModal() {
    const modalOverlay = document.getElementById("delete-modal-overlay");
    if (modalOverlay) {
        modalOverlay.classList.remove("show");
        setTimeout(() => modalOverlay.style.display = "none", 300);
    }
}

// Utility format price
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
}
